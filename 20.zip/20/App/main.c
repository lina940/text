/**********************************************************
*    模块：SmartClock
*    功能：智能电子时钟
*          (1) TIM2 秒定时，实现年-月-日 时:分:秒 星期走时
*          (2) OLED 显示时钟
*          (3) 按键设置年-月-日 时:分
**********************************************************/
#include "stm32f10x.h"
#include "BSP_Delay.h"
#include "BSP_LED.h"
#include "BSP_OLED.h"
#include "BSP_Timer.h"
#include "BSP_Key.h"
#include <stdio.h>

/*==================================================================
 * 时间及报警结构体定义
 *================================================================*/
typedef struct {
    uint16_t Year;
    uint8_t  Month;
    uint8_t  Day;
    uint8_t  Hour;
    uint8_t  Minute;
    uint8_t  Second;
    uint8_t  Weekday;
} Clock_TypeDef;

typedef struct {
    uint8_t Hour;
    uint8_t Minute;
    uint8_t Enable;
    uint8_t Triggered;
} Alarm_TypeDef;

/*==================================================================
 * 全局变量
 *================================================================*/
volatile uint32_t ms_tick = 0;
volatile uint8_t  one_second_flag = 0;
volatile uint32_t alarm_red_led_timer = 0;

volatile uint16_t g_year    = 2026;
volatile uint8_t  g_month   = 5;
volatile uint8_t  g_day     = 18;
volatile uint8_t  g_hour    = 14;
volatile uint8_t  g_minute  = 54;
volatile uint8_t  g_second  = 0;
volatile uint8_t  g_weekday = 1;

volatile Alarm_TypeDef g_alarms[3] = {0};
volatile uint16_t g_temp_adc = 0;

/* 按键设置状态 */
static uint8_t key_set_mode = 0;  /* 0:正常, 1:年, 2:月, 3:日, 4:时, 5:分 */
static uint8_t g_disp_update = 0; /* 需要刷新显示 */

/*==================================================================
 * 按键处理 (Key1切换设置项, Key2+, Key3-)
 * Key1-PB13, Key2-PB14, Key3-PB15, Key4-PD8
 *================================================================*/
static void Process_Key(void)
{
    uint8_t key_val = BSP_Key_Scan(Key1 | Key2 | Key3);

    if (key_val & Key1) {
        BSP_Delay_ms(50);  /* 消抖 */
        if (BSP_Key_Scan(Key1) & Key1) {
            key_set_mode++;
            if (key_set_mode > 5) key_set_mode = 0;
            g_disp_update = 1;
        }
    }

    if (key_val & Key2) {
        BSP_Delay_ms(50);
        if (BSP_Key_Scan(Key2) & Key2) {
            switch (key_set_mode) {
                case 1: if (++g_year > 2099) g_year = 2020; break;
                case 2: if (++g_month > 12) g_month = 1; break;
                case 3: if (++g_day > 31) g_day = 1; break;
                case 4: if (++g_hour > 23) g_hour = 0; break;
                case 5: if (++g_minute > 59) g_minute = 0; break;
                default: break;
            }
            g_disp_update = 1;
        }
    }

    if (key_val & Key3) {
        BSP_Delay_ms(50);
        if (BSP_Key_Scan(Key3) & Key3) {
            switch (key_set_mode) {
                case 1: if (--g_year < 2020) g_year = 2099; break;
                case 2: if (--g_month < 1) g_month = 12; break;
                case 3: if (--g_day < 1) g_day = 31; break;
                case 4: if (--g_hour > 23) g_hour = 23; break;
                case 5: if (--g_minute > 59) g_minute = 59; break;
                default: break;
            }
            g_disp_update = 1;
        }
    }
}

/*==================================================================
 * OLED 显示
 *================================================================*/
static void Display_Time(void)
{
    char buf[22];

    /* 第1行: 年-月-日 星期 */
    sprintf(buf, "%04d-%02d-%02d W%d", g_year, g_month, g_day, g_weekday);

    if (key_set_mode == 0)
        BSP_OLED_ShowString(0, 0, (uint8_t*)buf);
    else
        BSP_OLED_ShowString(0, 0, (uint8_t*)buf);  /* 可加高亮 */

    /* 第3行: 时:分:秒 */
    sprintf(buf, "  %02d:%02d:%02d", g_hour, g_minute, g_second);
    BSP_OLED_ShowString(0, 2, (uint8_t*)buf);

    /* 第5行: 设置模式提示 */
    if (key_set_mode > 0) {
        sprintf(buf, "Set: %d", key_set_mode);
        BSP_OLED_ShowString(0, 4, (uint8_t*)buf);
    } else {
        BSP_OLED_ShowString(0, 4, (uint8_t*)"Normal Mode ");
    }

    /* 第7行: 温度 */
    sprintf(buf, "Temp:%4d", g_temp_adc);
    BSP_OLED_ShowString(0, 6, (uint8_t*)buf);
}

/*==================================================================
 * 主函数
 *================================================================*/
int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

    BSP_LED_Init();
    BSP_Delay_Init();
    BSP_OLED_Init();
    BSP_Timer_Init();     /* TIM2 1ms中断 */
    BSP_Key_Init();

    GPIO_SetBits(GPIOE, GPIO_Pin_2);  /* 关闭红灯(PE2) */

    BSP_OLED_Clear();
    BSP_OLED_ShowString(0, 0, (uint8_t*)"SmartClock Init");
    BSP_Delay_ms(200);
    BSP_OLED_Clear();

    while (1)
    {
        /* 每秒更新 */
        if (one_second_flag) {
            one_second_flag = 0;
            Display_Time();
            BSP_LED_Toggle(LED0);  /* LED0闪烁指示运行 */
        }

        /* 按键扫描 */
        Process_Key();

        /* 进入设置模式时强制刷新 */
        if (g_disp_update) {
            g_disp_update = 0;
            Display_Time();
        }
    }
}
