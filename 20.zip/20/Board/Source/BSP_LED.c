/**********************************************************
*    ģ�飺BSP_LED 
*    �������弶 LED ����ģ������
		   LED0-PE6 LED1-PE2 LED2-PE3 LED3-PE4 LED4-PE5 �͵�ƽ����
*    ���ߣ�
*    ʱ�䣺
*    �汾��V1.0.0
**********************************************************/
#include "BSP_LED.h"

/* �ڲ��������� */
static void BSP_LED_GPIO_Init(void);

/*******************************************************
*	����˵��: �弶 LED ��ʼ������
*******************************************************/
void BSP_LED_Init(void)
{
	BSP_LED_GPIO_Init();
}

/*******************************************************
*	����˵��: �弶 LED GPIO �ڲ���ʼ������
*******************************************************/
static void BSP_LED_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_LED, ENABLE);//ʹ�ܶ�Ӧʱ��
	
	GPIO_InitStructure.GPIO_Pin = GPIO_PIN_LED0 | GPIO_PIN_LED1 | \
	                 GPIO_PIN_LED2 | GPIO_PIN_LED3 | GPIO_PIN_LED4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	 //�������
	GPIO_Init(GPIO_PORT_LED, &GPIO_InitStructure);
	
	BSP_LED_Off(LEDAll);
}

/*******************************************************
*	����˵��: �弶 LED���� ���ܺ���
*	��    ��: LEDNumber
*******************************************************/
void BSP_LED_On(uint8_t LEDNumber)
{
	if (LEDNumber & LED0)
		GPIO_ResetBits(GPIO_PORT_LED, GPIO_PIN_LED0);
	if (LEDNumber & LED1)
		GPIO_ResetBits(GPIO_PORT_LED, GPIO_PIN_LED1);
	if (LEDNumber & LED2)
		GPIO_ResetBits(GPIO_PORT_LED, GPIO_PIN_LED2);
	if (LEDNumber & LED3)
		GPIO_ResetBits(GPIO_PORT_LED, GPIO_PIN_LED3);
	if (LEDNumber & LED4)
		GPIO_ResetBits(GPIO_PORT_LED, GPIO_PIN_LED4);
}

/*******************************************************
*	����˵��: �弶 LEDϨ�� ���ܺ���
*	��    ��: LEDNumber
*******************************************************/
void BSP_LED_Off(uint8_t LEDNumber)
{
	if (LEDNumber & LED0)
		GPIO_SetBits(GPIO_PORT_LED, GPIO_PIN_LED0);		
	if (LEDNumber & LED1)
		GPIO_SetBits(GPIO_PORT_LED, GPIO_PIN_LED1);
	if (LEDNumber & LED2)
		GPIO_SetBits(GPIO_PORT_LED, GPIO_PIN_LED2);
	if (LEDNumber & LED3)
		GPIO_SetBits(GPIO_PORT_LED, GPIO_PIN_LED3);
	if (LEDNumber & LED4)
		GPIO_SetBits(GPIO_PORT_LED, GPIO_PIN_LED4);
}

/***************************************************
*	����˵��: �弶 LED ״̬��ת���ܺ���
*	��    ��: LEDNumber
****************************************************/
void BSP_LED_Toggle(uint8_t LEDNumber)
{
	uint8_t val;
	if (LEDNumber & LED0){
		val = GPIO_ReadOutputDataBit(GPIO_PORT_LED, GPIO_PIN_LED0);
		GPIO_WriteBit(GPIO_PORT_LED, GPIO_PIN_LED0, (BitAction)(!val)); 		
	}
	if (LEDNumber & LED1){
		val = GPIO_ReadOutputDataBit(GPIO_PORT_LED, GPIO_PIN_LED1);
		GPIO_WriteBit(GPIO_PORT_LED, GPIO_PIN_LED1, (BitAction)(!val)); 		
	}
	if (LEDNumber & LED2){
		val = GPIO_ReadOutputDataBit(GPIO_PORT_LED, GPIO_PIN_LED2);
		GPIO_WriteBit(GPIO_PORT_LED, GPIO_PIN_LED2, (BitAction)(!val)); 		
	}
	if (LEDNumber & LED3){
		val = GPIO_ReadOutputDataBit(GPIO_PORT_LED, GPIO_PIN_LED3);
		GPIO_WriteBit(GPIO_PORT_LED, GPIO_PIN_LED3, (BitAction)(!val)); 		
	}
	if (LEDNumber & LED4){
		val = GPIO_ReadOutputDataBit(GPIO_PORT_LED, GPIO_PIN_LED4);
		GPIO_WriteBit(GPIO_PORT_LED, GPIO_PIN_LED4, (BitAction)(!val)); 		
	}
}
