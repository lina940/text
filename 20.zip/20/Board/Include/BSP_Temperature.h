#ifndef __BSP_TEMPERATURE_H
#define __BSP_TEMPERATURE_H

#include "stm32f10x.h"

extern int temper;

void T_ADC_Init(void);

int Get_Temperature(void);

#endif
